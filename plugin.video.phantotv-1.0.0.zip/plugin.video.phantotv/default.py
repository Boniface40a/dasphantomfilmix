import xbmc
import xbmcaddon
import xbmcgui

dialog = xbmcgui.Dialog()
if dialog.yesno("PhantoTV", "Download and install PhantoTV APK?"):
    xbmc.executebuiltin('StartAndroidActivity("https://boniface40a.github.io/dasphantomfilmix/filmix.fix-v-player.v2.2.9.apk")')
